/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.contacteditor;

import my.contacteditor.ContactEditorUI;

/**
 *
 * @author User
 */
public class ContactEditor {
    
    public static void main(String[] args) {
        ContactEditorUI form = new ContactEditorUI();
        form.setVisible(true);
    }
}
